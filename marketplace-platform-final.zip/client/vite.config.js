// Vite config for client
