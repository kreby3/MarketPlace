// Main entry for client
